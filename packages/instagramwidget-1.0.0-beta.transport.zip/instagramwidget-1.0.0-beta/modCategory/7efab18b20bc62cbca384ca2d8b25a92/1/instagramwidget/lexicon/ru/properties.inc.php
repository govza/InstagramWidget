<?php
$_lang['instagramwidget_prop_id'] = 'обязательно указать client id из панели управления приложениями Instagram';
$_lang['instagramwidget_prop_login'] = 'обязательно для отображения данных пользователя';
$_lang['instagramwidget_prop_hashtag'] = 'вывод изображений по хештегу';

$_lang['instagramwidget_prop_random'] = 'перемешать изображения';
$_lang['instagramwidget_prop_cacheExpTime'] = 'время хранения кэша в часах';

$_lang['instagramwidget_prop_width'] = 'ширина виджета, число или % (указывайте)';
$_lang['instagramwidget_prop_imageSize'] = 'размер превью Instagram используемый для эскизов';
$_lang['instagramwidget_prop_limit'] = 'ограничение количества выводимых изображений';
$_lang['instagramwidget_prop_inLine'] = 'количество изображений в ряду';

$_lang['instagramwidget_prop_cssFile'] = 'путь к файлу стилей. Изменить или удалить если пользуетесь своими стилями и шаблонами';
$_lang['instagramwidget_prop_wrapper'] = 'wrapper виджета (+inUser, +inAvatar, +inPosts, +inFollowers, +inFollowing, +inImages)';
$_lang['instagramwidget_prop_tpl'] = 'tpl для изображений (+link, +src)';

//todo
$_lang['instagramwidget_prop_sortBy'] = 'Поле сортировки.';
$_lang['instagramwidget_prop_sortDir'] = 'Направление сортировки.';
$_lang['instagramwidget_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
